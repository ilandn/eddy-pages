A Pen created at CodePen.io. You can find this one at https://codepen.io/eyalstr/pen/MqLLWE.

 #####Sweet Animated Memory Game