Monster Wants Candy demo
========================

Monster Wants Candy demo is a simple HTML5 game created with Phaser 2.0.7 and available at: http://candy-demo.enclavegames.com/

You can read the detailed tutorial about the demo at Tuts+ Game Development: http://gamedevelopment.tutsplus.com/tutorials/getting-started-with-phaser-building-monster-wants-candy--cms-21723

![Monster Wants Candy - screen](https://cms-assets.tutsplus.com/uploads/users/22/posts/21723/image/monster-demo-screens.jpg)

You can also play the full game at: http://enclavegames.com/games/monster-wants-candy/

## Licensing

This game demo is licensed under the **Creative Commons Attribution-NonCommercial 4.0 International** (CC BY-NC 4.0). See the [human-readable summary](http://creativecommons.org/licenses/by-nc/4.0/) or [legalcode](http://creativecommons.org/licenses/by-nc/4.0/legalcode) for details.

Under this license you are permitted to remix/reuse/redistribute my work as long as you credit me ([Andrzej Mazur](http://end3r.com/)) for the original work and don’t use it for commercial purposes. If someone does wish to use it in a commercial context, they should e-mail me at andrzej.mazur@end3r.com to discuss the terms of use.