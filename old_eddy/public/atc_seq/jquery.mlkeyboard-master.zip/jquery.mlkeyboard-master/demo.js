$(document).ready(function(){
  $('input#example-1').mlKeyboard({layout: 'en_US'});
});

$(document).ready(function(){
  $('input#example-2').mlKeyboard({layout: 'ru_RU'});
});

$(document).ready(function(){
  $('input#example-3').mlKeyboard({layout: 'es_ES'});
});

$(document).ready(function(){
  $('input#example-4').mlKeyboard({layout: 'it_IT', trigger: '#example-4-btn'});
});

$(document).ready(function(){
  $('input#example-5').mlKeyboard({layout: 'fr_FR', trigger: '#example-5-btn'});
});

$(document).ready(function(){
  $('textarea#example-6').mlKeyboard({layout: 'pt_PT', trigger: '#example-6-btn'});
});
