export const servicesConfig = {
    URL: 'http://54.205.68.225:8080'
};